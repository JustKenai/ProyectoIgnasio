package dsy1103.gimnasio.dto.request;

import lombok.Data;

@Data
@A
public class SocioRequestDTO {
    @NotBlank(message = "Debe ingresar un nombre")
    private String nombres;

    @NotBlank(message = "Debe ingresar un apellido")
    private String apellidos;

    @NotNull(message = "Debe ingresar un run")
    private String run;

    @NotNull(message = "Ingrese un numero de telefono")
    private Integer telefono;

    @NotNull(message = "Ingrese una fecha de nacimiento")
    private LocalDate fechaNacimiento;

    @NotNull(message = "El socio debe tener un plan activo")
    private Long planSuscripcion_ID;

    @NotNull(message = "Debe indicar si el socio esta activo o inactivo")
    private boolean estado;
}
