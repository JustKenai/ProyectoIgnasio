package dsy1103.gimnasio.dto.response;

public class SocioResponseDTO {
}
