package dsy1103.gimnasio.config;

import dsy1103.gimnasio.model.Entrenador;
import dsy1103.gimnasio.model.Horario;
import dsy1103.gimnasio.repository.ClaseRepository;
import dsy1103.gimnasio.repository.EntrenadorRepository;
import dsy1103.gimnasio.repository.HorarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Date;

/*
 * * ═══════════════════════════════════════════════════
 * DataInitializer.java
 * Inserta datos de prueba al arrancar la aplicación.
 *
 * ESTRATEGIA "insertar una sola vez":
 *   Antes de insertar, preguntamos cuántos registros
 *   hay en la BD. Si ya hay datos (count > 0), no
 *   hacemos nada. Así:
 *     - Al borrar manualmente datos en phpMyAdmin
 *       NO se vuelven a insertar (conteo > 0 si hay
 *       otros datos, o hay que reiniciar con BD vacía).
 *     - Si la BD está completamente vacía (nuevo despliegue
 *       o BD recreada), se insertan automáticamente.
 *   Esta es la forma más simple y directa para clase.
 * ═══════════════════════════════════════════════════

 * @Slf4j (Lombok): genera automáticamente un logger
 *   'log' para usar log.info(), log.warn(), etc.
 *   Sin Lombok sería: private static final Logger log = ...
 * */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInializer implements CommandLineRunner{

    private final ClaseRepository claseRepository;
    private final EntrenadorRepository entrenadorRepository;
    private final HorarioRepository horarioRepository;

    @Override
    public void run(String... args) {

        if (claseRepository.count() > 0) {
            log.info(">>> DataInitializer: la BD ya tiene datos, se omite la carga inicial.");
            return;
        }

        log.info(">>> DataInitializer: BD vacía detectada, insertando datos de prueba...");


        Horario horario1 = horarioRepository.save(new Horario(null, "Clase de Brazos", LocalDate.now(), LocalDate.now()));
        Horario horario2 = horarioRepository.save(new Horario(null, "Clase de Pierna",LocalDate.now(), LocalDate.now()));
        Horario horario3 = horarioRepository.save(new Horario(null, "Clase de Yoga", LocalDate.now(), LocalDate.now()));
        log.info(">>> DataInitializer: {} categorías y {} libros insertados correctamente.",
                entrenadorRepository.count(), horarioRepository.count());

        Entrenador entrenador1 = entrenadorRepository.save(
                new Entrenador(null, "Joaquin", "Orellana", "390123-3","Yoga","6759356", horario3));
    }

}