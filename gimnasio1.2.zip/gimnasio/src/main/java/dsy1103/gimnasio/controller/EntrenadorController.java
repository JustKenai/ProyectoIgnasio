package dsy1103.gimnasio.controller;

import dsy1103.gimnasio.dto.request.EntrenadorRequestDTO;
import dsy1103.gimnasio.service.EntrenadorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ignasio/entrenador")
@RequiredArgsConstructor
public class EntrenadorController {
    private  final EntrenadorService entrenadorService;

    @GetMapping("/{especialidad}")
    public ResponseEntity<?> buscarPorEspecialidad(@PathVariable String especialidad){
        return ResponseEntity.ok(entrenadorService.buscarPorEspecialidad(especialidad));
    }

    @PostMapping("/agregar")
    public ResponseEntity<?> agregarEntrenador(@Valid @RequestBody EntrenadorRequestDTO dto){
        return ResponseEntity.status(201).body(entrenadorService.guardar(dto));
    }


}
