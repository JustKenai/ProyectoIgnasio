package dsy1103.gimnasio.service;

import dsy1103.gimnasio.repository.SocioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SocioService {

    private final SocioRepository socioRepository;


}
